<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Applicant_table extends Model
{
    
    public $timestamps = true; 
    public $guarded = [];
}
