<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contac extends Model
{
    public $timestamps = true; 
    public $guarded = [];
}
