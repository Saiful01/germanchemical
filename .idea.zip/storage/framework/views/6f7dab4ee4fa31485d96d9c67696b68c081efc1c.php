<?php $__env->startSection('content'); ?>

<div class="slider bg-navy-blue bg-scroll pos-rel breadcrumbs-page">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/"><i class="icofont-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Apply</li>
                </ol>
            </nav>

            <h1 class="text-center" style="color:orange;">Apply For Job</h1>


            <div class="breadcrumbs-description">
                Molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto.
            </div>
        </div>
    </div>

    <main id="body-content">


        <!-- Contact Details Start -->
        <section class="wide-tb-80 contact-full-shadow">
            <div class="container">


<div class="col-md-7 col-sm-12 col-lg-7 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s" style="visibility: visible; animation-delay: 0s; animation-name: fadeInLeft;">
                        <div class="contact-detail-shadow">
                            <h1 class="heading-main mb-4">
                                Get in touch
                            </h1>

                            <form action="/email" method="post" id="contactusForm" novalidate="novalidate" class="col rounded-field">
                                <div class="form-row mb-4">
                                    <div class="col">
                                    <label>Applicant name:</label>
                                        <input type="text" class="form-control" placeholder="Name" name="app_name">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                                    </div>

                                </div>
                                <div class="form-row mb-4">
                                    <div class="col">
                                    <label>Job Qualification:</label>
                                       <textarea type="text" class="form-control" placeholder="Qualification" name="app_max_edu"></textarea>
                                    </div>


                                    
                                <div class="form-row mb-4">

                                    <div class="col">
                                    <label>Phone:</label>
                                        <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone">
                                    </div>
                                
                                    <div class="col">
                                    <label>Email:</label>
                                        <input type="text" name="email" id="email" class="form-control" placeholder="Email">
                                    </div>
                                </div>
                                    <div class="col">
                                    <label>Applicant Password:</label>
                                     <input type="text" class="form-control" placeholder="Password" name="app_password">
                                    </div>
                                </div>

                                <div class="form-row text-center">

                                    <button id="contactForm" type="submit" class="form-btn mx-auto btn-theme bg-orange">Submit Now <i class="icofont-rounded-right"></i></button>
                                </div>
                            </form>

                        </div>
                    </div>

                    </div>
        </section>




    </main>
 </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/pages/career/applyjob.blade.php ENDPATH**/ ?>