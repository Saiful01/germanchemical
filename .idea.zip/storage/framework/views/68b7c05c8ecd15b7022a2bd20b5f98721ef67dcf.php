<?php $__env->startSection('title','Jobs'); ?>



<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\laravel projct\germanchmical\resources\views/pages/jobs.blade.php ENDPATH**/ ?>