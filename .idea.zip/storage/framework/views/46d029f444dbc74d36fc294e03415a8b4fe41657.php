<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/employee/update" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Employee Name:</label>
                    <input type="text" class="form-control" name="emp_name" value="<?php echo e($result->emp_name); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <input type="hidden" name="emp_id" value="<?php echo e($result->emp_id); ?>">
                </div>


                <div class="form-group">
                    <label>Employee Email:</label>
                    <input type="email" class="form-control"  name="emp_email" value=" <?php echo e($result->emp_email); ?> ">
                </div>
                <div class="form-group">
                    <label>Employee phone:</label>
                    <input type="number" class="form-control"  name="emp_phone" value=" <?php echo e($result->emp_phone); ?> ">
                </div>
                <div class="form-group">
                    <label>Employee Bio:</label>
                    <input type="text" class="form-control"  name="emp_bio" value=" <?php echo e($result->emp_bio); ?> ">
                </div>
                <div class="form-group">
                    <label>Employee Picture:</label>
                    <input type="file" class="form-control"  name="emp_image" value=" <?php echo e($result->emp_image); ?> ">
                </div>
                <div class="form-group">
                    <label>Employee Designation:</label>
                    <input type="text" class="form-control"  name="emp_designation" value=" <?php echo e($result->emp_designation); ?> ">
                </div>
                <div class="form-group">
                    <label>Employee Joining Date:</label>
                    <input type="test" class="form-control"  name="emp_join_date" value=" <?php echo e($result->emp_join_date); ?> ">
                </div>


                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/employee/edit.blade.php ENDPATH**/ ?>