<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">

   <h1 class="text-center text-primary">Contact List</h1>
  </div>


    <div class="card-body">
    
    <?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<?php if(Session::has('failed')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
<?php endif; ?>
<table class="table table-bordered">
<thead>
<tr>
<th>#</th>
<th>Contact name</th>
<th> Email</th>
<th> phone</th>
<th> message</th>
</tr>
</thead>

<?php ($i=1); ?>
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($res->con_name); ?> </td>
<td><?php echo e($res->con_email); ?> </td>
<td><?php echo e($res->con_phone); ?></td>
<td><?php echo e($res->con_msg); ?></td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/contac/view.blade.php ENDPATH**/ ?>