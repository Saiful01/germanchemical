<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/slider/update" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Name:</label>
                    <input type="text" class="form-control" placeholder="Name" name="slider_name" value="<?php echo e($result->slider_name); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <input type="hidden" name="slider_id" value="<?php echo e($result->slider_id); ?>">

                </div>


                <div class="form-group">
                    <label>Title:</label>
                    <input type="text" class="form-control" placeholder="Name" name="slider_title"value="<?php echo e($result->slider_title); ?>">
                </div>


                <div class="form-group">
                    <label>Sub Title:</label>
                    <input type="text" class="form-control" placeholder="Name" name="slider_sub_title"value="<?php echo e($result->slider_sub_title); ?>">
                </div>

                <div class="form-group">
                    <label>Image:</label>
                    <input type="file" class="form-control" placeholder="Name" name="image"value="<?php echo e($result->image); ?>">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>