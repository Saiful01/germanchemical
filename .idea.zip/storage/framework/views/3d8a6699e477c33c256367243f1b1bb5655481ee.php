<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">

            <div class="row">
                <div class="col-md-6">
                    <h4>Slider</h4>
                </div>

                <div class="col-md-6">
                    <a class="btn btn-success float-right" href="/slider/create">New</a>
                </div>
            </div>

        </div>

        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Slider name</th>
                    <th>Slider Title</th>
                    <th>Slider Sub Title</th>
                    <th>Slider Image</th>
                    <th>Slider Edit</th>
                    <th>Slider Delete</th>


                </tr>
                </thead>

                <?php ($i=1); ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($res->slider_name); ?> </td>
                        <td><?php echo e($res->slider_title); ?> </td>
                        <td><?php echo e($res->slider_sub_title); ?> </td>
                        <td><?php echo e($res->slider_image); ?></td>
                        <td><a class="btn btn-info" href="/slider/edit/<?php echo e($res->slider_id); ?>">Edit</a></td>
                        <td><a class="btn btn-danger" href="/slider/delete/<?php echo e($res->slider_id); ?>">Delete</a></td>


                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/slider/show.blade.php ENDPATH**/ ?>