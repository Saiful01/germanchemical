<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/job/update" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Job Title:</label>
                    <input type="text" class="form-control" placeholder="title" name="job_title" value="<?php echo e($result->job_title); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <input type="hidden" name="job_id" value="<?php echo e($result->job_id); ?>">
                </div>


                <div class="form-group">
                    <label>Job Description:</label>
                    <textarea type="text" class="form-control"  name="job_description"> <?php echo e($result->job_description); ?>  </textarea>
                </div>


                <div class="form-group">
                    <label>Job Qualification:</label>
                    <textarea type="text" class="form-control"  name="job_qualification"><?php echo e($result->job_qualification); ?> </textarea>
                </div>


                
                <div class="form-group">
                    <label>Job Vacancy:</label>
                    <input type="number" class="form-control" placeholder="vacancy" name="job_vacancy"value="<?php echo e($result->job_vacancy); ?>">
                </div>
                
                <div class="form-group">
                    <label>Job Salary:</label>
                    <input type="number" class="form-control" placeholder="Salary" name="job_salary"value="<?php echo e($result->job_salary); ?>">
                </div>
                
                <div class="form-group">
                    <label>Job Experience:</label>
                    <input type="text" class="form-control" placeholder="Experience" name="job_experience"value="<?php echo e($result->job_experience); ?>">
                </div>


                <div class="form-group">
                <label>Job Emlpoyment Status:</label>
                <select class="form-control form-control-lg" name="job_employment_status">
                <option <?php if($result->job_employment_status=="Full Time"): ?> selected <?php endif; ?> >Full time</option>
                <option <?php if($result->job_employment_status=="Part Time"): ?> selected <?php endif; ?>>Part time</option>
                </select>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/job/edit.blade.php ENDPATH**/ ?>