<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/applicant/store" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Applicant name:</label>
                    <input type="text" class="form-control"  name="app_name">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                </div>


                <div class="form-group">
                    <label>Applicant Email:</label>
                    <textarea type="text" class="form-control"  name="app_email"></textarea>
                </div>


                <div class="form-group">
                    <label>Applicant Max Education level:</label>
                    <select class="form-control form-control-lg" name="app_max_edu">
                <option>JSC</option>
                <option>SSC</option>
                <option>HSC</option>
                <option>Graduate</option>
                <option>Masters</option>
                <option>PHD</option>
                
                </select>
                </div>

                

                
                <div class="form-group">
                    <label>Phone:</label>
                    <input type="number" class="form-control" name="app_phone">
                </div>
                
                <div class="form-group">
                    <label>Applicant Password:</label>
                    <input type="text" class="form-control" name="app_password">
                </div>
                
                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/applicant/create.blade.php ENDPATH**/ ?>