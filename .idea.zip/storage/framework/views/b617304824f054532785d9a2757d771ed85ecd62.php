<?php $__env->startSection('title','Products'); ?>



<?php $__env->startSection('content'); ?>
<div class="slider bg-navy-blue bg-scroll pos-rel breadcrumbs-page">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/"><i class="icofont-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page"></li>
                </ol>
            </nav>

            <h1 class="text-center"> OUR PRODUCTS</h1>
            <div class="breadcrumbs-description">
            </div>
        </div>
    </div>

    <main id="body-content">
    <section id="">
        <div class="container mt-5">
            <div class="row">

                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card">

                            <div class="card-body">
                                <a href="/pages/products/details/<?php echo e($res->pro_id); ?>">
                                    <img class="card-img-top" src="/images/product/<?php echo e($res->pro_image); ?>" alt="Product image"
                                         width="100%" height="250px">
                                </a>
                                <hr>
                                <!-- <p class="text-success"><b>Price :</b> <?php echo e($res->pro_price); ?> tk</p> -->
                                <p class="headline text-center ">
                                    <a class="text-info font-weight-bold"  href="/pages/products/details/<?php echo e($res->pro_id); ?>"><?php echo e($res->pro_title); ?></a>
                                </p>


                            </div>
                        </div>
                        <br>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


    </section>


        <!-- Contact Details Start -->
        <section class="wide-tb-80 contact-full-shadow">
            <div class="container">

                <?php if(Session::has('success')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(Session::has('failed')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('failed')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main> 
 </div> 
 </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/pages/products/products.blade.php ENDPATH**/ ?>