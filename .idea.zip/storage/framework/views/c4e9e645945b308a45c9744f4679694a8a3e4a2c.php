<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/product/update" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Product Name:</label>
                    <input type="text" class="form-control" name="pro_title" value="<?php echo e($result->pro_title); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <input type="hidden" name="pro_id" value="<?php echo e($result->pro_id); ?>">
                </div>

                <div class="form-group">
                    <label>Product Details:</label>
                    <textarea type="text" class="form-control"  name="pro_details"><?php echo e($result->pro_details); ?>"</textarea>
                </div>

                <div class="form-group">
                    <label>Product Image :</label>
                    <input type="file" class="form-control" name="pro_image" value="<?php echo e($result->pro_image); ?>">
                </div>
                
                <div class="form-group">
                    <label>Product Price:</label>
                    <input type="text" class="form-control" name="pro_price" value="<?php echo e($result->pro_price); ?>">
                </div>


                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>