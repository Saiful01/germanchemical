<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/contac/store" enctype='multipart/form-data'>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name"  name="con_name">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                </div>


                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email"  name="con_email">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Phone"  name="con_phone">
                </div>

               
                <div class="form-group">
                <textarea type="text" class="form-control" placeholder="Write message" name="con_msg"></textarea>
                </div>
                
                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\German Chemical\german chemical backup - Copy\resources\views/admin/contac/create.blade.php ENDPATH**/ ?>