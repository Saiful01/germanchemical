@extends('layouts.app')

@section('content')
    <div class="card">
        <div class="card-body">

            @if(Session::has('success'))
                <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('success') }}</p>
            @endif

            @if(Session::has('failed'))
                <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('failed') }}</p>
            @endif

            <form method="post" action="/contac/store" enctype='multipart/form-data'>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name"  name="con_name">
                    <input type="hidden" name="_token" value="{{{ csrf_token() }}}"/>
                </div>


                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email"  name="con_email">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Phone"  name="con_phone">
                </div>

               
                <div class="form-group">
                <textarea type="text" class="form-control" placeholder="Write message" name="con_msg"></textarea>
                </div>
                
                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>


@endsection
